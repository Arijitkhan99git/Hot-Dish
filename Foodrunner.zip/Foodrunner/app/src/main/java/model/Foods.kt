package model

data class Foods(
    val foodId:String,
    val foodName:String,
    val foodPrice:String,
    val restaurantId:String
)