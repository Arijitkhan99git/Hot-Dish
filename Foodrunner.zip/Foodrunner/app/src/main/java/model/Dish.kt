package model

data class Dish(
    val dishId:String,
    val dishName:String,
    val dishRating:String,
    val dishPrice:String,
    val dishImage:String
)
