package com.internshala.foodrunner

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class HomePageActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home_page)

        title="Welcome Page"
    }
}
